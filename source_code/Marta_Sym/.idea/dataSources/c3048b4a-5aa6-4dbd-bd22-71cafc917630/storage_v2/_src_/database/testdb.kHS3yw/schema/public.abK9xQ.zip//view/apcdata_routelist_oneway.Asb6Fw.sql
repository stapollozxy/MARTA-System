create view apcdata_routelist_oneway as
  SELECT apcdata_source.route,
    unique_stopid_per_name.min_stop_id
   FROM apcdata_source,
    unique_stopid_per_name
  WHERE (((apcdata_source.stop_name)::text = (unique_stopid_per_name.min_stop_name)::text) AND ((apcdata_source.direction)::text = ANY (ARRAY[('Northbound'::character varying)::text, ('Eastbound'::character varying)::text, ('Clockwise'::character varying)::text])));

