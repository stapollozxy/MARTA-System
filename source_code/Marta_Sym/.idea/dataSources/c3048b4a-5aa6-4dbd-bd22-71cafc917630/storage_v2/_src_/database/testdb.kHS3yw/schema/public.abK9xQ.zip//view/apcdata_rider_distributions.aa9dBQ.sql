create view apcdata_rider_distributions as
  SELECT temp.min_stop_id,
    temp.route,
    temp.time_slot,
    min(temp.on_sum) AS min_ons,
    trunc(avg(temp.on_sum)) AS avg_ons,
    max(temp.on_sum) AS max_ons,
    min(temp.off_sum) AS min_offs,
    trunc(avg(temp.off_sum)) AS avg_offs,
    max(temp.off_sum) AS max_offs
   FROM ( SELECT apcdata_source.calendar_day,
            apcdata_source.min_stop_id,
            apcdata_source.route,
            date_part('hour'::text, apcdata_source.arrival_time) AS time_slot,
            sum(apcdata_source.ons) AS on_sum,
            sum(apcdata_source.offs) AS off_sum
           FROM apcdata_source
          GROUP BY apcdata_source.calendar_day, apcdata_source.min_stop_id, apcdata_source.route, (date_part('hour'::text, apcdata_source.arrival_time))) temp
  WHERE (temp.time_slot IS NOT NULL)
  GROUP BY temp.min_stop_id, temp.route, temp.time_slot;

