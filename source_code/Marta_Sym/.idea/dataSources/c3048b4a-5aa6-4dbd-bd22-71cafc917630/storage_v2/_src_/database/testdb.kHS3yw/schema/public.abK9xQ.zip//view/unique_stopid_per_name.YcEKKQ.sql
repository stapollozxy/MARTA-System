create view unique_stopid_per_name as
  SELECT min(apcdata_activity_only.stop_id) AS min_stop_id,
    apcdata_activity_only.stop_name AS min_stop_name
   FROM apcdata_activity_only
  GROUP BY apcdata_activity_only.stop_name;

