create view apcdata_stops as
  SELECT apcdata_source.min_stop_id,
    apcdata_source.stop_name,
    avg(apcdata_source.latitude) AS latitude,
    avg(apcdata_source.longitude) AS longitude
   FROM apcdata_source
  GROUP BY apcdata_source.min_stop_id, apcdata_source.stop_name;

