create view apcdata_travel_time as
  SELECT apcdata_source1.min_stop_id AS origin,
    temp.min_stop_id AS destination,
    avg((((date_part('hour'::text, (temp.arrival_time - apcdata_source1.arrival_time)) * (3600)::double precision) + (date_part('minute'::text, (temp.arrival_time - apcdata_source1.arrival_time)) * (60)::double precision)) + date_part('second'::text, (temp.arrival_time - apcdata_source1.arrival_time)))) AS travel_time
   FROM (apcdata_source1
     JOIN apcdata_source1 temp ON (((apcdata_source1.row_number + 1) = temp.row_number)))
  WHERE ((apcdata_source1.route > 1000) AND (temp.arrival_time > apcdata_source1.arrival_time))
  GROUP BY apcdata_source1.min_stop_id, temp.min_stop_id;

