create view apcdata_bus_distributions as
  SELECT temp.route,
    min(temp.bus_count) AS min_buses,
    trunc(avg(temp.bus_count)) AS avg_buses,
    max(temp.bus_count) AS max_buses
   FROM ( SELECT apcdata_source.calendar_day,
            apcdata_source.route,
            count(DISTINCT apcdata_source.vehicle_number) AS bus_count
           FROM apcdata_source
          GROUP BY apcdata_source.calendar_day, apcdata_source.route) temp
  GROUP BY temp.route;

