create view location_checks as
  SELECT temp.min_stop_id,
    temp.stop_name,
    (((temp.max_lat - temp.min_lat) ^ (2)::numeric) + ((temp.max_long - temp.min_long) ^ (2)::numeric)) AS distance_diff
   FROM ( SELECT apcdata_source.min_stop_id,
            apcdata_source.stop_name,
            max(apcdata_source.latitude) AS max_lat,
            min(apcdata_source.latitude) AS min_lat,
            max(apcdata_source.longitude) AS max_long,
            min(apcdata_source.longitude) AS min_long
           FROM apcdata_source
          GROUP BY apcdata_source.min_stop_id, apcdata_source.stop_name) temp
  ORDER BY (((temp.max_lat - temp.min_lat) ^ (2)::numeric) + ((temp.max_long - temp.min_long) ^ (2)::numeric)) DESC;

