create view apcdata_source as
  SELECT apcdata_activity_only.calendar_day,
    apcdata_activity_only.route,
    apcdata_activity_only.route_name,
    apcdata_activity_only.direction,
    unique_stopid_per_name.min_stop_id,
    apcdata_activity_only.stop_name,
    apcdata_activity_only.arrival_time,
    apcdata_activity_only.departure_time,
    apcdata_activity_only.ons,
    apcdata_activity_only.offs,
    apcdata_activity_only.latitude,
    apcdata_activity_only.longitude,
    apcdata_activity_only.vehicle_number
   FROM apcdata_activity_only,
    unique_stopid_per_name
  WHERE ((apcdata_activity_only.stop_name)::text = (unique_stopid_per_name.min_stop_name)::text)
  ORDER BY apcdata_activity_only.vehicle_number, apcdata_activity_only.calendar_day, apcdata_activity_only.arrival_time, apcdata_activity_only.departure_time;

