create view apcdata_activity_only as
  SELECT apcdata.calendar_day,
    apcdata.route,
    apcdata.route_name,
    apcdata.direction,
    apcdata.stop_id,
    apcdata.stop_name,
    apcdata.arrival_time,
    apcdata.departure_time,
    apcdata.ons,
    apcdata.offs,
    apcdata.latitude,
    apcdata.longitude,
    apcdata.vehicle_number
   FROM apcdata
  WHERE (((apcdata.ons > 0) OR (apcdata.offs > 0)) AND (apcdata.latitude IS NOT NULL) AND (apcdata.longitude IS NOT NULL) AND ((apcdata.arrival_time IS NOT NULL) OR (apcdata.departure_time IS NOT NULL)));

