create view apcdata_routes as
  SELECT DISTINCT apcdata_source.route,
    apcdata_source.route_name
   FROM apcdata_source;

